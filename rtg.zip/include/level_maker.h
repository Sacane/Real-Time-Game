#ifndef __LEVEL_MAKER__H__
#define __LEVEL_MAKER__H__

#include "niveau.h"

#include "board.h"



Plateau niveau0();

Board niveau0_b();

Plateau niveau1();

Plateau niveau2();
 
Plateau niveau3();

Board board_level0();

#endif
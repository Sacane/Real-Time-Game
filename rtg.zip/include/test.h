#ifndef __TEST__H__
#define __TEST__H__

#include "level_maker.h"
#include "time.h"
#include "management.h"

void main_test();

#endif
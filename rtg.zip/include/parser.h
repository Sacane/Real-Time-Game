#ifndef __PARSER__H__
#define __PARSER__H__

#include <string.h>
#include "niveau.h"
#include "temps.h"


Plateau read_file(char* name_file);


#endif
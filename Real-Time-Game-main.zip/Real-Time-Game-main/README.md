# REAL TIME GAME

Real time game using heaps to manage event's priorities in C

Made by Johan "Sacane" Ramaroson and Christine Li
